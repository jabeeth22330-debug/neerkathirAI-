# NEERKATHIR AI – Vivasayi Guard
Offline crop disease/pest detection and advisory for farmers. Bharat AI-SoC Challenge, Problem Statement 1 (Agriculture & Food Security).
Target hardware: Arm-based Android phone (Vivo Y22: MediaTek Helio G70, 4 GB RAM). Models: MobileNetV3-small (vision) and Llama 3.2 1B-Instruct (advice wording) through ExecuTorch.

- **Live app (installable, works offline after first load):** https://YOUR-USERNAME.github.io/neerkathir-ai/  *(replace YOUR-USERNAME)*
- **Demo video (2 min):** ADD LINK
- **Final report:** see `docs/` or ADD LINK

## What it does
Farmer registers (PIN, details encrypted on the phone) > photographs a leaf > answers a few questions > gets the likely problem, visible-damage %, an honest "uncertain" when unsure, Tamil/English advice with voice, sourced pesticide and fertiliser names (never doses) with safety rules, and a field-memory record for follow-up. A shared-phone kiosk mode and printable Crop Passport serve farmers without smartphones.

## Honest status
| Part | Status |
|---|---|
| Web/PWA app (this site) | Works. Diagnosis logic is rule-based. |
| Android project (`android/`) | Written; not yet compiled or tested on a device |
| Vision model training (`training/`) | Colab notebook written; update this row after training |
| Llama 3.2 via ExecuTorch | Hook written (`LlamaAdvisor.kt`); update after running on the phone |
| Knowledge base (`knowledge/`) | Tomato only, draft; needs expert review and CIB&RC registration check |
| Benchmarks | In-app button written; add measured numbers to the report |
This is a preliminary AI screening tool, not a confirmed diagnosis.

## Folders
- `index.html`, `sw.js`, `manifest.webmanifest`: installable web app (GitHub Pages)
- `android/`: Android Studio project (arm64, no INTERNET permission)
- `training/`: Colab notebook and training/export script
- `knowledge/`: advice database and validator (`python validate_kb.py`)
- `docs/`: plans, checklist, demo script, Vivo Y22 notes

## Build the Android app
Open `android/` in Android Studio > Build > Build APK. Train the model with `training/NEERKATHIR_train_tomato_colab.ipynb`, then copy `tomato_mobilenet.pte` and `classes.txt` to `/sdcard/Android/data/com.neerkathir.ai/files/` with adb.

## Safety
No doses are shown. Products are names listed in a university guide, to be confirmed with an agricultural officer.

## Licence
MIT for our code (see LICENSE). Datasets and models keep their own licences.
